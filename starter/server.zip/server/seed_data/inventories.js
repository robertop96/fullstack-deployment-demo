module.exports = [
  {
    name: "Product One",
    description: "one awesome product for photographers",
    quantity: 400,
    status: "In Stock"
  },
  {
    name: "Product Two",
    description: "one awesome product for chefs",
    quantity: 800,
    status: "In Stock"
  },
  {
    name: "Product One",
    description: "one awesome product for musicians",
    quantity: 90,
    status: "Out Of Stock"
  }
];
