const knexConfig = require("./knexfile");
const knex = require("knex")(knexConfig);
const bookshelf = require("bookshelf")(knex);

module.exports = bookshelf;
